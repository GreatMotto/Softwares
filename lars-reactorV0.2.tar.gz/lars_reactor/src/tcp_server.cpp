#include <iostream>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <strings.h>
#include <arpa/inet.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include "tcp_server.h"
#include "reactor_buf.h"

void lars_hello()
{
    std::cout <<"lars Hello" <<std::endl;
}


//构造函数
tcp_server::tcp_server(const char *ip, uint16_t port)
{
    //0. 忽略一些信号  SIGHUP, SIGPIPE
    if (signal(SIGHUP, SIG_IGN) == SIG_ERR)  {
        fprintf(stderr, "signal ignore SIGHUB\n");
    }

    if (signal(SIGPIPE, SIG_IGN) == SIG_ERR)  {
        fprintf(stderr, "signal ignore SIGHUB\n");
    }
    
    //1. 创建socket
    _sockfd = socket(AF_INET, SOCK_STREAM |SOCK_CLOEXEC, IPPROTO_TCP) ;
    if (_sockfd == -1) {
        fprintf(stderr, "tcp::server :socket()\n");
        exit(1);
    }



    //2 初始化服务器的地址
    struct sockaddr_in server_addr;
    bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    inet_aton(ip, &server_addr.sin_addr);
    server_addr.sin_port = htons(port);


    //2.5 设置sock可以重复监听
    int op = 1;
    if (setsockopt(_sockfd, SOL_SOCKET, SO_REUSEADDR, &op, sizeof(op)) < 0) {
        fprintf(stderr, "set socketopt reuse error\n");
    }
    
    //3 绑定端口
    if (bind(_sockfd, (const struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        fprintf(stderr, "bind error\n");
        exit(1);
    }
    
    //4 监听
    if (listen(_sockfd, 500) == -1) {
        fprintf(stderr , "listen error\n");
        exit(1);
    }
}

//开始提供创建链接的服务
void tcp_server::do_accept()
{
    int connfd;
    while (true) {
        //1 accept
        connfd = accept(_sockfd, (struct sockaddr*)&_connaddr, &_addrlen);
        if (connfd == -1) {
            if (errno == EINTR)  {
                //中断错误
                fprintf(stderr, "accept errno = EINTR\n");
                continue;
            }
            else if (errno == EAGAIN) {
                fprintf(stderr, "accept errno = EAGAIN\n");
                break;
            }
            else if (errno == EMFILE) {
                //建立链接过多， 资源不够
                fprintf(stderr, "accept errno = EMFILE\n");
                continue;
            }
            else {
                fprintf(stderr, "accept error");
                exit(1);
            }
        }
        else {
            //accept succ!
            //TODO 添加一些心跳机制
            //TODO 添加消息队列机制
            
            //写一个回显业务 回显客户端数据
            int ret = 0;
            input_buf ibuf;
            output_buf obuf;

            char *msg = NULL;
            int msg_len = 0;
            
            //将数据读到input_buf中
            do {
                ret = ibuf.read_data(connfd);
                if (ret == -1) {
                    fprintf(stderr, "ibuf read_data error\n");
                    break;
                }

                //将ibuf中的数据 进行业务处理
                msg_len = ibuf.length();
                msg = (char*)malloc(msg_len);
                bzero(msg, msg_len);
                memcpy(msg, ibuf.data(), msg_len);
            
                ibuf.pop(msg_len);
                ibuf.adjust();

                printf("recv data = %s\n", msg);
                
                
                
                //将数据写到output_buf中
                obuf.send_data(msg, msg_len);
                while (obuf.length()) {
                    int write_ret = obuf.write2fd(connfd);
                    if (write_ret == -1) {
                        fprintf(stderr, "write2fd error\n");
                        return;
                    }
                    else if (write_ret == 0) {
                        //表示当前fd是不可写,但是不是一个错误,稍后回来再写
                        break;
                    }
                }

                free(msg);

            } while (ret != 0);


            //对点客户端已经正常关闭
            close(connfd);
        }
    }
}

//析构函数  资源的释放
tcp_server::~tcp_server()
{
    close(_sockfd);
}
